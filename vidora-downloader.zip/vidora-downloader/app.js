const $=id=>document.getElementById(id);
const toast=(msg)=>{const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)};
$('year').textContent=new Date().getFullYear();
document.querySelectorAll('.tab').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===btn));$('linkPanel').classList.toggle('hidden',btn.dataset.tab!=='link');$('filePanel').classList.toggle('hidden',btn.dataset.tab!=='file')}));
$('clear').onclick=()=>{$('url').value='';$('linkResult').classList.add('hidden')};
function fmtBytes(n){if(!Number.isFinite(n)||n<=0)return 'Size unavailable';const u=['B','KB','MB','GB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return `${n.toFixed(i?2:0)} ${u[i]}`}
function fmtTime(s){if(!Number.isFinite(s))return 'Unknown duration';return `${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,'0')}`}
function isYoutube(u){try{const h=new URL(u).hostname.replace(/^www\./,'');return h==='youtube.com'||h==='m.youtube.com'||h==='youtu.be'||h==='music.youtube.com'}catch{return false}}
function safeName(url){try{return decodeURIComponent(new URL(url).pathname.split('/').pop())||'video'}catch{return 'video'}}
function showResult(target,html){target.innerHTML=html;target.classList.remove('hidden')}
$('inspect').onclick=async()=>{
 const raw=$('url').value.trim();if(!raw){toast('Please paste a video URL first.');return}
 let u;try{u=new URL(raw);if(!['http:','https:'].includes(u.protocol))throw 0}catch{toast('Please enter a valid http or https URL.');return}
 const out=$('linkResult');out.classList.add('hidden');
 if(isYoutube(u.href)){
  let id='';if(u.hostname.includes('youtu.be'))id=u.pathname.slice(1);else id=u.searchParams.get('v')||u.pathname.split('/').filter(Boolean).pop();
  const thumb=id?`https://img.youtube.com/vi/${encodeURIComponent(id)}/hqdefault.jpg`:'';
  showResult(out,`${thumb?`<img class="video-preview" src="${thumb}" alt="YouTube thumbnail" onerror="this.style.display='none'">`:''}<h3>YouTube video link detected</h3><div class="meta"><span class="chip">YouTube</span><span class="chip">Preview only</span></div><div class="notice">YouTube does not provide a public direct-download URL through this page. To download your own upload, use YouTube Studio → Content → ⋮ → Download, or use Google Takeout. We won’t bypass platform restrictions.</div><p><a class="download" href="${u.href}" target="_blank" rel="noopener">Open video on YouTube ↗</a></p>`);
  return;
 }
 const btn=$('inspect');btn.disabled=true;btn.querySelector('span').textContent='Checking link…';
 try{
  const res=await fetch(u.href,{method:'HEAD',mode:'cors'});
  if(!res.ok)throw new Error('The host did not allow a file check.');
  const type=res.headers.get('content-type')||'';
  if(!type.startsWith('video/'))throw new Error('This link does not appear to point directly to a video file.');
  const size=fmtBytes(Number(res.headers.get('content-length')));
  const name=safeName(u.href);
  showResult(out,`<video class="video-preview" controls preload="metadata" src="${u.href.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"></video><h3>${name.replace(/[<>&"]/g,'')}</h3><div class="meta"><span class="chip">${type.split(';')[0]}</span><span class="chip">${size}</span><span class="chip">Direct video</span></div><a class="download" href="${u.href.replace(/"/g,'%22')}" download>↓ &nbsp; Download video</a><div class="hint">If the server blocks downloads or CORS, open the link in a new tab and use your browser’s save option.</div>`);
 }catch(e){showResult(out,`<h3>Couldn’t inspect this link</h3><div class="notice">${String(e.message||'The link is not publicly accessible as a direct video file.').replace(/[<>&"]/g,'')}</div><p class="hint">Try a direct MP4/WebM file link, or choose a video from your device in the other tab. Some hosts block browser inspection.</p>`)}
 finally{btn.disabled=false;btn.querySelector('span').textContent='Inspect video'}
};
$('fileInput').addEventListener('change',()=>{
 const f=$('fileInput').files[0];if(!f)return;if(!f.type.startsWith('video/')){toast('Please choose a video file.');return}
 const url=URL.createObjectURL(f);const out=$('fileResult');
 const v=document.createElement('video');v.src=url;v.preload='metadata';v.className='video-preview';v.controls=true;
 const title=document.createElement('h3');title.textContent=f.name;
 const meta=document.createElement('div');meta.className='meta';
 const chips=[f.type||'Video',fmtBytes(f.size)];chips.forEach(x=>{const c=document.createElement('span');c.className='chip';c.textContent=x;meta.append(c)});
 const a=document.createElement('a');a.className='download';a.href=url;a.download=f.name;a.textContent='↓  Save a copy';
 const note=document.createElement('div');note.className='hint';note.textContent='This file is already on your device. Use Save a copy to download another copy.';
 out.replaceChildren(v,title,meta,a,note);out.classList.remove('hidden');
 v.addEventListener('loadedmetadata',()=>{const c=document.createElement('span');c.className='chip';c.textContent=`${v.videoWidth} × ${v.videoHeight} · ${fmtTime(v.duration)}`;meta.append(c)});
});
